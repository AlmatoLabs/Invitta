"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState, type FormEvent } from "react";
import { api, type GuestGroup, type RsvpStatus } from "@/lib/api";
import { qk, useGuestGroups, useTables } from "@/lib/queries";
import { useSession } from "@/lib/session";

const statusLabel: Record<RsvpStatus, string> = {
  confirmat: "Confirmat",
  asteptare: "În așteptare",
  refuzat: "Refuzat",
};
const statusClass: Record<RsvpStatus, string> = {
  confirmat: "bg-champagne/20 text-foreground",
  asteptare: "bg-secondary text-muted-foreground",
  refuzat: "bg-destructive/10 text-destructive",
};

const csvCell = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;

export default function RsvpPage() {
  const session = useSession();
  const invitationId = session?.invitation?.id;
  const qc = useQueryClient();
  const { data: groups = [], isPending } = useGuestGroups(invitationId);
  const { data: tables = [] } = useTables(invitationId);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"toti" | RsvpStatus>("toti");
  const [adding, setAdding] = useState(false);

  const tableName = useMemo(() => {
    const names = new Map(tables.map((t) => [t.id, t.name]));
    return (g: GuestGroup) => {
      const ids = new Set(g.members.map((m) => m.tableId).filter(Boolean) as string[]);
      return [...ids].map((id) => names.get(id)).filter(Boolean).join(", ");
    };
  }, [tables]);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: qk.groups(invitationId) });
    qc.invalidateQueries({ queryKey: qk.stats(invitationId) });
    qc.invalidateQueries({ queryKey: qk.tables(invitationId) });
  };

  const setStatus = useMutation({
    mutationFn: (v: { id: string; status: RsvpStatus }) =>
      api(`/guest-groups/${v.id}`, { method: "PATCH", body: { status: v.status } }),
    onSuccess: refresh,
  });
  const remove = useMutation({
    mutationFn: (id: string) => api(`/guest-groups/${id}`, { method: "DELETE" }),
    onSuccess: refresh,
  });

  const visible = groups.filter(
    (g) =>
      (filter === "toti" || g.status === filter) &&
      g.name.toLowerCase().includes(search.toLowerCase()),
  );

  const exportCsv = () => {
    const rows = [
      ["Nume", "Status", "Persoane", "Masă", "Meniu", "Mesaj"],
      ...groups.map((g) => [g.name, statusLabel[g.status], g.people, tableName(g), g.menu ?? "", g.message ?? ""]),
    ];
    const blob = new Blob(["﻿" + rows.map((r) => r.map(csvCell).join(",")).join("\n")], {
      type: "text/csv;charset=utf-8",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "invitati.csv";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">Confirmări</p>
          <h1 className="mt-2 font-serif text-4xl">Invitații voștri</h1>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setAdding((a) => !a)} className="rounded-[4px] bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90">
            {adding ? "Închide" : "Adaugă invitat"}
          </button>
          <button onClick={exportCsv} className="rounded-full border border-border bg-card px-5 py-2.5 text-sm hover:bg-secondary">
            Exportă lista
          </button>
        </div>
      </div>

      {adding && invitationId && (
        <AddGuestForm invitationId={invitationId} onDone={() => { refresh(); setAdding(false); }} />
      )}

      <div className="flex flex-wrap gap-3 items-center mb-8">
        <input
          placeholder="Caută invitat..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 min-w-[200px] rounded-full border border-border bg-card px-5 py-3 text-sm outline-none focus:border-champagne"
        />
        <div className="flex gap-2 flex-wrap">
          {(["toti", "confirmat", "asteptare", "refuzat"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-[4px] px-4 py-2 text-sm transition-colors ${filter === f ? "bg-noir text-ivory" : "bg-card border border-border text-muted-foreground hover:text-foreground"}`}
            >
              {f === "toti" ? "Toți" : statusLabel[f]}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto rounded-md border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-secondary/50 text-xs uppercase tracking-[0.15em] text-muted-foreground">
            <tr>
              <th className="text-left font-normal px-6 py-4">Nume</th>
              <th className="text-left font-normal px-6 py-4">Status</th>
              <th className="text-left font-normal px-6 py-4">Persoane</th>
              <th className="text-left font-normal px-6 py-4">Masă</th>
              <th className="text-left font-normal px-6 py-4">Meniu</th>
              <th className="px-6 py-4" />
            </tr>
          </thead>
          <tbody>
            {visible.map((g) => (
              <tr key={g.id} className="border-t border-border hover:bg-secondary/30 transition-colors">
                <td className="px-6 py-5">
                  <span className="font-serif text-lg">{g.name}</span>
                  {g.message && <p className="mt-1 max-w-xs text-xs text-muted-foreground">„{g.message}”</p>}
                </td>
                <td className="px-6 py-5">
                  <select
                    value={g.status}
                    onChange={(e) => setStatus.mutate({ id: g.id, status: e.target.value as RsvpStatus })}
                    className={`rounded-[4px] border-0 px-3 py-1 text-xs outline-none ${statusClass[g.status]}`}
                    aria-label="Status"
                  >
                    {(Object.keys(statusLabel) as RsvpStatus[]).map((s) => (
                      <option key={s} value={s}>{statusLabel[s]}</option>
                    ))}
                  </select>
                </td>
                <td className="px-6 py-5">{g.people}</td>
                <td className="px-6 py-5 text-muted-foreground">{tableName(g) || "—"}</td>
                <td className="px-6 py-5 text-muted-foreground capitalize">{g.menu ?? "—"}</td>
                <td className="px-6 py-5 text-right">
                  <button
                    onClick={() => { if (confirm(`Ștergi „${g.name}”?`)) remove.mutate(g.id); }}
                    className="text-xs text-muted-foreground hover:text-destructive"
                  >
                    Șterge
                  </button>
                </td>
              </tr>
            ))}
            {!isPending && visible.length === 0 && (
              <tr><td colSpan={6} className="px-6 py-16 text-center text-muted-foreground">Niciun invitat găsit.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AddGuestForm({ invitationId, onDone }: { invitationId: string; onDone: () => void }) {
  const [name, setName] = useState("");
  const [partner, setPartner] = useState("");
  const add = useMutation({
    mutationFn: () =>
      api(`/invitations/${invitationId}/guest-groups`, {
        body: {
          name,
          status: "asteptare",
          people: partner.trim() ? 2 : 1,
          members: [{ name }, ...(partner.trim() ? [{ name: partner.trim(), isPartner: true }] : [])],
        },
      }),
    onSuccess: onDone,
  });
  const submit = (e: FormEvent) => {
    e.preventDefault();
    add.mutate();
  };
  const field = "w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none focus:border-champagne";
  return (
    <form onSubmit={submit} className="mb-8 grid gap-4 rounded-md border border-border bg-card p-6 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
      <div>
        <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Nume invitat sau familie</label>
        <input required value={name} onChange={(e) => setName(e.target.value)} className={`${field} mt-2`} />
      </div>
      <div>
        <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Partener (opțional)</label>
        <input value={partner} onChange={(e) => setPartner(e.target.value)} className={`${field} mt-2`} />
      </div>
      <button disabled={add.isPending} className="rounded-[4px] bg-primary px-6 py-3 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60">
        Adaugă
      </button>
      {add.error && <p role="alert" className="text-sm text-destructive sm:col-span-3">{add.error.message}</p>}
    </form>
  );
}
