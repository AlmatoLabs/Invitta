"use client";

import Link from "next/link";
import { useInvitation } from "@/lib/queries";
import { useStats } from "@/lib/queries";
import { useSession } from "@/lib/session";

export default function MyInvites() {
  const session = useSession();
  const hasInvite = session?.hasInvite === true;
  const { data: invitation } = useInvitation(session?.invitation?.id);
  const { data: stats } = useStats(session?.invitation?.id);
  const c = invitation?.content ?? {};
  const couple = [c.brideFirst, c.groomFirst].filter(Boolean).join(" & ") || session?.name || "";
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">Contul tău</p>
      <h1 className="mt-3 font-serif text-5xl">Invitațiile mele</h1>
      <div className="mt-12 grid gap-6 md:grid-cols-2">
        {!hasInvite ? (
          <div className="rounded-md border border-border bg-card p-8">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Nicio invitație încă</p>
            <h2 className="mt-3 font-serif text-3xl">Începe prima ta invitație</h2>
            <p className="mt-2 text-sm text-muted-foreground">Alege un model din colecție și personalizează-l.</p>
            <div className="mt-8"><Link href="/modele" className="rounded-[4px] bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90">Alege un model</Link></div>
          </div>
        ) : (
        <div className="rounded-md border border-border bg-card p-8">
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Activă{typeof c.dateLabel === "string" && c.dateLabel ? ` · ${c.dateLabel}` : ""}</p>
          <h2 className="mt-3 font-serif text-3xl">{couple}</h2>
          <p className="mt-2 text-sm text-muted-foreground">invitta.ro/{session?.invitation?.slug} · {stats?.confirmed ?? 0} confirmări</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/dashboard/invitatie" className="rounded-[4px] bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90">Editează invitația</Link>
            <Link href={`/invitatie/${session?.invitation?.slug}`} className="rounded-[4px] border border-border px-5 py-2.5 text-sm hover:bg-muted">Vezi invitația</Link>
            <Link href="/dashboard/rsvp" className="rounded-[4px] border border-border px-5 py-2.5 text-sm hover:bg-muted">Vezi RSVP-uri</Link>
          </div>
        </div>
        )}
        {hasInvite && (
          <Link href="/modele" className="flex min-h-[220px] flex-col items-center justify-center rounded-md border border-dashed border-border p-8 text-center hover:bg-muted">
            <span className="font-serif text-4xl">+</span>
            <span className="mt-2 text-sm">Schimbă modelul</span>
          </Link>
        )}
      </div>
    </div>
  );
}
