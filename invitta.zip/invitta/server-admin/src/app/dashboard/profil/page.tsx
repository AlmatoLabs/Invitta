"use client";

import { useEffect, useState, type FormEvent } from "react";
import { api } from "@/lib/api";
import { useSession, useUpdateProfile } from "@/lib/session";

const input = "mt-2 w-full border-0 border-b border-border bg-transparent py-3 outline-none focus:border-foreground transition-colors";
const label = "text-xs uppercase tracking-[0.2em] text-muted-foreground";

export default function Profile() {
  const session = useSession();
  const update = useUpdateProfile();
  const [form, setForm] = useState({ name: "", email: "", phone: "" });
  const [saved, setSaved] = useState(false);
  const [pwMsg, setPwMsg] = useState("");
  const [pw, setPw] = useState({ cur: "", next: "", confirm: "" });

  useEffect(() => {
    if (session) setForm({ name: session.name, email: session.email, phone: session.phone ?? "" });
  }, [session]);

  const save = (e: FormEvent) => {
    e.preventDefault();
    update.mutate(
      { name: form.name, email: form.email, phone: form.phone || null },
      {
        onSuccess: () => {
          setSaved(true);
          setTimeout(() => setSaved(false), 2000);
        },
      },
    );
  };

  const changePw = async (e: FormEvent) => {
    e.preventDefault();
    if (pw.next.length < 8) return setPwMsg("Parola nouă trebuie să aibă minim 8 caractere.");
    if (pw.next !== pw.confirm) return setPwMsg("Parolele nu coincid.");
    try {
      await api("/me/password", { body: { current: pw.cur, next: pw.next } });
      setPw({ cur: "", next: "", confirm: "" });
      setPwMsg("Parola a fost schimbată.");
    } catch (err) {
      setPwMsg(err instanceof Error ? err.message : "A apărut o eroare.");
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">Contul tău</p>
      <h1 className="mt-3 font-serif text-5xl">Profilul meu</h1>

      <form onSubmit={save} className="mt-12 space-y-6">
        <h2 className="font-serif text-2xl">Detaliile mele</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <div><label className={label}>Nume</label><input required className={input} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className={label}>Email</label><input type="email" required className={input} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div><label className={label}>Telefon</label><input className={input} placeholder="07xx xxx xxx" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
        </div>
        {update.error && <p role="alert" className="text-sm text-destructive">{update.error.message}</p>}
        <button disabled={update.isPending} className="rounded-[4px] bg-primary px-6 py-3 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60">{saved ? "✓ Salvat" : "Salvează"}</button>
      </form>

      <form onSubmit={changePw} className="mt-16 space-y-6 border-t border-border pt-12">
        <h2 className="font-serif text-2xl">Schimbă parola</h2>
        <div><label className={label}>Parola curentă</label><input type="password" required className={input} value={pw.cur} onChange={(e) => setPw({ ...pw, cur: e.target.value })} /></div>
        <div className="grid gap-6 md:grid-cols-2">
          <div><label className={label}>Parola nouă</label><input type="password" required className={input} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /></div>
          <div><label className={label}>Confirmă parola</label><input type="password" required className={input} value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} /></div>
        </div>
        {pwMsg && <p className="text-sm text-muted-foreground">{pwMsg}</p>}
        <button className="rounded-[4px] border border-foreground px-6 py-3 text-sm hover:bg-muted">Schimbă parola</button>
      </form>
    </div>
  );
}
