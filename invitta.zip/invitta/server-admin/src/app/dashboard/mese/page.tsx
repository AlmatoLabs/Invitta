"use client";

import { useQueryClient } from "@tanstack/react-query";
import { useMemo, useState, type DragEvent } from "react";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { api, type GuestGroup, type SeatingTable as Table, type TableShape as Shape } from "@/lib/api";
import { qk, useGuestGroups, useInvitation, useTables } from "@/lib/queries";
import { useSession } from "@/lib/session";

type NewTable = { name: string; seats: number; shape: Shape; color: string; notes: string };

const TABLE_COLORS = [
  "#C9A876", "#7A8B5C", "#B89E8A", "#8FA1B3", "#A77C7C", "#9B8AA8", "#6E7F6A", "#2A2A2A",
];

const SHAPES: { id: Shape; label: string }[] = [
  { id: "round", label: "Rotundă" },
  { id: "rect", label: "Dreptung." },
  { id: "square", label: "Pătrat" },
  { id: "oval", label: "Ovală" },
  { id: "presidium", label: "Prezidiu" },
];

export default function Tables() {
  const session = useSession();
  const invitationId = session?.invitation?.id;
  const qc = useQueryClient();
  const { data: invitation } = useInvitation(invitationId);
  const { data: tables = [] } = useTables(invitationId);
  const { data: groups = [] } = useGuestGroups(invitationId);
  const [search, setSearch] = useState("");
  const [zoom, setZoom] = useState(100);
  const [selected, setSelected] = useState<string | null>(null);
  const [dragged, setDragged] = useState<{ guestId: string; from: string | "pool" } | null>(null);
  const [error, setError] = useState("");

  const tablesKey = qk.tables(invitationId);
  const groupsKey = qk.groups(invitationId);
  const refresh = () => {
    qc.invalidateQueries({ queryKey: tablesKey });
    qc.invalidateQueries({ queryKey: groupsKey });
  };
  const run = async (fn: () => Promise<unknown>) => {
    setError("");
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : "A apărut o eroare.");
    } finally {
      refresh();
    }
  };

  const assigned = useMemo(() => new Set(tables.flatMap((t) => t.guests.map((g) => g.id))), [tables]);
  const totalSeats = tables.reduce((a, t) => a + t.seats, 0);
  const totalAssigned = tables.reduce((a, t) => a + t.guests.length, 0);
  const visibleGroups = groups
    .map((g: GuestGroup) => ({ ...g, members: g.members.filter((m) => m.name.toLowerCase().includes(search.toLowerCase())) }))
    .filter((g) => g.members.length > 0);

  const onDragStart = (guestId: string, from: string | "pool") => setDragged({ guestId, from });

  /** Seats a guest (or sends them back to the pool with `null`). Optimistic, rolled back on error. */
  const seat = (guestId: string, tableId: string | null) => {
    const guest =
      groups.flatMap((g) => g.members).find((m) => m.id === guestId);
    if (!guest) return;
    qc.setQueryData<Table[]>(tablesKey, (old = []) =>
      old.map((t) => {
        const without = t.guests.filter((g) => g.id !== guestId);
        return t.id === tableId ? { ...t, guests: [...without, { id: guestId, name: guest.name }] } : { ...t, guests: without };
      }),
    );
    run(() => api(`/guests/${guestId}`, { method: "PATCH", body: { tableId } }));
  };

  const onDrop = (e: DragEvent, toId: string) => {
    e.preventDefault();
    if (!dragged) return;
    const table = tables.find((t) => t.id === toId);
    if (!table || table.guests.some((g) => g.id === dragged.guestId) || table.guests.length >= table.seats) return;
    seat(dragged.guestId, toId);
    setDragged(null);
  };
  const onDropPool = (e: DragEvent) => {
    e.preventDefault();
    if (!dragged || dragged.from === "pool") return;
    seat(dragged.guestId, null);
    setDragged(null);
  };

  const addTable = (t: NewTable) =>
    run(async () => {
      const { table } = await api<{ table: Table }>(`/invitations/${invitationId}/tables`, { body: t });
      setSelected(table.id);
    });
  const removeTable = (id: string) => run(() => api(`/tables/${id}`, { method: "DELETE" }));
  const updateTable = (id: string, patch: Partial<Table>) =>
    run(() => api(`/tables/${id}`, { method: "PATCH", body: patch }));

  const c = invitation?.content ?? {};
  const couple = [c.brideFirst, c.groomFirst].filter(Boolean).join(" & ");
  const subtitle = ["Invitațiile mele", couple, typeof c.dateLabel === "string" ? c.dateLabel : ""].filter(Boolean).join(" · ");

  return (
    <div className="min-h-[calc(100vh-80px)] flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-ivory/90 backdrop-blur-xl px-4 sm:px-8 py-5">
        <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">
          {subtitle}
        </p>
        <h1 className="mt-2 font-serif text-3xl sm:text-4xl">Așezarea la mese</h1>
      </div>

      {/* Toolbar */}
      <div className="border-b border-border bg-card px-4 sm:px-8 py-3 flex flex-wrap items-center gap-2">
        <NewTableDialog onCreate={addTable} />
        <ToolbarButton icon="＋">Element nou</ToolbarButton>
        <ToolbarButton icon="◐">Grup nou</ToolbarButton>
        <div className="mx-2 h-6 w-px bg-border hidden sm:block" />
        <ToolbarButton icon="▦">Sumar</ToolbarButton>
        <ToolbarButton icon="↗">Export</ToolbarButton>
        <ToolbarButton icon="◉">3D</ToolbarButton>
        <ToolbarButton icon="?">Ajutor</ToolbarButton>
        <div className="ml-auto flex items-center gap-2 text-xs text-champagne">
          <span className="h-2 w-2 rounded-full bg-champagne" /> Salvat automat
        </div>
      </div>

      {error && (
        <p role="alert" className="border-b border-border bg-destructive/10 px-4 py-2 text-sm text-destructive sm:px-8">{error}</p>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[280px_1fr]">
        {/* Left: guest pool */}
        <aside className="border-r border-border bg-card/50 flex flex-col max-h-[calc(100vh-200px)]">
          <div className="p-4 border-b border-border">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">⌕</span>
              <input
                value={search} onChange={(e) => setSearch(e.target.value)}
                placeholder="Caută invitat..."
                className="w-full rounded-xl border border-border bg-ivory pl-9 pr-4 py-2.5 text-sm outline-none focus:border-champagne"
              />
            </div>
          </div>

          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={onDropPool}
            className="flex-1 overflow-y-auto px-3 py-4"
          >
            <p className="px-2 text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-3">
              Neasignați ({visibleGroups.reduce((a, g) => a + g.members.filter((m) => !assigned.has(m.id)).length, 0)})
            </p>

            <div className="space-y-4">
              {visibleGroups.map((g) => (
                <div key={g.id}>
                  <p className="px-3 py-1 text-[11px] uppercase tracking-wider text-muted-foreground/70 border-b border-border/60 mb-1">
                    {g.name}
                  </p>
                  {g.members.map((m) => {
                    const isAssigned = assigned.has(m.id);
                    return (
                      <div
                        key={m.id}
                        draggable={!isAssigned}
                        onDragStart={() => !isAssigned && onDragStart(m.id, "pool")}
                        className={`mt-1 flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition ${
                          isAssigned ? "opacity-40 line-through" : "cursor-grab bg-secondary/40 hover:bg-champagne/15"
                        }`}
                      >
                        <span className="h-2 w-2 rounded-full border border-muted-foreground/40" />
                        <span className="flex-1 truncate">{m.name}</span>
                        {m.isPartner && (
                          <span className="text-[9px] uppercase tracking-wider text-muted-foreground bg-ivory rounded-[4px] px-2 py-0.5">
                            partener
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Canvas */}
        <main className="relative bg-[oklch(0.97_0.008_80)] overflow-auto">
          <div
            className="min-h-full p-8"
            style={{
              backgroundImage:
                "radial-gradient(circle, oklch(0.85 0.012 75) 1px, transparent 1px)",
              backgroundSize: "24px 24px",
            }}
          >
            <div
              className="flex flex-wrap gap-10 origin-top-left transition-transform"
              style={{ transform: `scale(${zoom / 100})` }}
            >
              {tables.map((t) => (
                <TableShape
                  key={t.id}
                  table={t}
                  selected={selected === t.id}
                  onSelect={() => setSelected(t.id)}
                  onDrop={(e) => onDrop(e, t.id)}
                  onDragGuest={(guestId) => onDragStart(guestId, t.id)}
                  onRemove={() => removeTable(t.id)}
                  onSeatsChange={(seats) => updateTable(t.id, { seats })}
                />
              ))}
              {tables.length === 0 && (
                <div className="m-auto text-center text-muted-foreground py-32">
                  <p className="font-serif text-2xl">Nicio masă încă</p>
                  <p className="mt-2 text-sm">Folosește „Masă nouă” pentru a începe</p>
                </div>
              )}
            </div>
          </div>

          {/* Footer stats + zoom */}
          <div className="sticky bottom-0 flex items-center justify-between gap-4 border-t border-border bg-ivory/95 backdrop-blur-xl px-6 py-3">
            <p className="text-xs text-muted-foreground">
              <span className="font-serif text-base text-foreground">{totalAssigned}</span> / {totalSeats} locuri ocupate ·{" "}
              <span className="font-serif text-base text-foreground">{tables.length}</span> mese
            </p>
            <div className="flex items-center gap-1">
              <ZoomBtn onClick={() => setZoom(Math.max(50, zoom - 10))}>−</ZoomBtn>
              <span className="text-xs tabular-nums w-12 text-center">{zoom}%</span>
              <ZoomBtn onClick={() => setZoom(Math.min(150, zoom + 10))}>＋</ZoomBtn>
              <ZoomBtn onClick={() => setZoom(100)}>⟲</ZoomBtn>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function ToolbarButton({ icon, children }: { icon: string; children: React.ReactNode }) {
  return (
    <button className="inline-flex items-center gap-2 rounded-full bg-secondary/50 hover:bg-secondary px-4 py-2 text-xs text-foreground transition">
      <span className="text-champagne">{icon}</span> {children}
    </button>
  );
}

function ZoomBtn({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button onClick={onClick} className="h-8 w-8 rounded-full border border-border hover:bg-secondary text-sm">
      {children}
    </button>
  );
}

/* ---------------- Table Shape ---------------- */

function TableShape({
  table, selected, onSelect, onDrop, onDragGuest, onRemove, onSeatsChange,
}: {
  table: Table; selected: boolean;
  onSelect: () => void;
  onDrop: (e: DragEvent) => void;
  onDragGuest: (guestId: string) => void;
  onRemove: () => void;
  onSeatsChange: (n: number) => void;
}) {
  const free = table.seats - table.guests.length;

  const seatPositions = useMemo(() => {
    if (table.shape === "round" || table.shape === "oval") {
      return Array.from({ length: table.seats }).map((_, i) => {
        const angle = (i / table.seats) * Math.PI * 2 - Math.PI / 2;
        const rx = table.shape === "oval" ? 130 : 100;
        const ry = 100;
        return { x: Math.cos(angle) * rx, y: Math.sin(angle) * ry, angle };
      });
    }
    // Rect / square / presidium → seats on top + bottom
    const top = Math.ceil(table.seats / 2);
    const bot = table.seats - top;
    const width = table.shape === "square" ? 140 : table.shape === "presidium" ? 260 : 220;
    const stepT = top > 1 ? width / (top - 1) : 0;
    const stepB = bot > 1 ? width / (bot - 1) : 0;
    const positions = [
      ...Array.from({ length: top }).map((_, i) => ({ x: -width / 2 + i * stepT, y: -75, angle: -Math.PI / 2 })),
      ...Array.from({ length: bot }).map((_, i) => ({ x: -width / 2 + i * stepB, y: 75, angle: Math.PI / 2 })),
    ];
    return positions;
  }, [table.shape, table.seats]);

  const shapeBox = () => {
    const base = "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center text-ivory font-serif transition-all";
    const style = { background: table.color };
    switch (table.shape) {
      case "round":
        return <div className={`${base} h-32 w-32 rounded-full`} style={style}>
          <span className="text-sm">{table.name}</span>
          <span className="text-xs opacity-80">{table.guests.length}/{table.seats}</span>
        </div>;
      case "oval":
        return <div className={`${base} h-28 w-48 rounded-[50%]`} style={style}>
          <span className="text-sm">{table.name}</span>
          <span className="text-xs opacity-80">{table.guests.length}/{table.seats}</span>
        </div>;
      case "square":
        return <div className={`${base} h-28 w-28 rounded-md`} style={style}>
          <span className="text-sm">{table.name}</span>
          <span className="text-xs opacity-80">{table.guests.length}/{table.seats}</span>
        </div>;
      case "presidium":
        return <div className={`${base} h-20 w-72 rounded-md`} style={style}>
          <span className="text-sm">{table.name} · Prezidiu</span>
          <span className="text-xs opacity-80">{table.guests.length}/{table.seats}</span>
        </div>;
      case "rect":
      default:
        return <div className={`${base} h-24 w-56 rounded-md`} style={style}>
          <span className="text-sm">{table.name}</span>
          <span className="text-xs opacity-80">{table.guests.length}/{table.seats}</span>
        </div>;
    }
  };

  return (
    <div
      onClick={onSelect}
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
      className={`group relative h-[300px] w-[300px] rounded-md transition-all ${
        selected ? "ring-2 ring-champagne ring-offset-2 ring-offset-[oklch(0.97_0.008_80)]" : ""
      }`}
    >
      <div className="absolute inset-0">
        {shapeBox()}
        {/* Seats */}
        {seatPositions.map((p, i) => {
          const guest = table.guests[i];
          return (
            <div
              key={i}
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{ transform: `translate(calc(-50% + ${p.x}px), calc(-50% + ${p.y}px))` }}
            >
              {guest ? (
                <div
                  draggable
                  onDragStart={() => onDragGuest(guest.id)}
                  className="cursor-grab rounded-md bg-ivory border border-border px-2 py-1 text-[10px] whitespace-nowrap max-w-[100px] truncate luxe-shadow"
                  title={guest.name}
                >
                  {guest.name}
                </div>
              ) : (
                <div className="h-6 w-6 rounded border border-dashed border-muted-foreground/40 bg-ivory/60" />
              )}
            </div>
          );
        })}
      </div>

      {/* Controls */}
      {selected && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1 rounded-[4px] bg-noir text-ivory px-2 py-1 text-xs">
          <button onClick={(e) => { e.stopPropagation(); onSeatsChange(Math.max(1, table.seats - 1)); }} className="h-6 w-6 hover:bg-ivory/10 rounded-full">−</button>
          <span className="px-1 tabular-nums">{table.seats}</span>
          <button onClick={(e) => { e.stopPropagation(); onSeatsChange(table.seats + 1); }} className="h-6 w-6 hover:bg-ivory/10 rounded-full">＋</button>
          <span className="mx-1 h-3 w-px bg-ivory/30" />
          <button onClick={(e) => { e.stopPropagation(); onRemove(); }} className="h-6 w-6 hover:bg-destructive rounded-full">🗑</button>
        </div>
      )}

      {free > 0 && (
        <div className="absolute bottom-2 right-2 text-[10px] uppercase tracking-wider text-champagne">
          {free} libere
        </div>
      )}
    </div>
  );
}

/* ---------------- New Table Dialog ---------------- */

function NewTableDialog({ onCreate }: { onCreate: (t: NewTable) => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("Masa nouă");
  const [seats, setSeats] = useState(8);
  const [shape, setShape] = useState<Shape>("round");
  const [color, setColor] = useState(TABLE_COLORS[0]);
  const [notes, setNotes] = useState("");

  const submit = () => {
    onCreate({ name, seats, shape, color, notes });
    setOpen(false);
    setName("Masa nouă");
    setSeats(8);
    setShape("round");
    setColor(TABLE_COLORS[0]);
    setNotes("");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="inline-flex items-center gap-2 rounded-[4px] bg-noir text-ivory hover:opacity-90 px-4 py-2 text-xs transition">
          <span className="text-champagne">＋</span> Masă nouă
        </button>
      </DialogTrigger>
      <DialogContent className="bg-ivory border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">Masă nouă</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 mt-2">
          <div>
            <label className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Nume masă *</label>
            <input value={name} onChange={(e) => setName(e.target.value)}
              className="mt-2 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none focus:border-champagne" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Capacitate *</label>
              <input type="number" min={1} max={30} value={seats}
                onChange={(e) => setSeats(Number(e.target.value))}
                className="mt-2 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none focus:border-champagne" />
            </div>
            <div>
              <label className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Culoare</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {TABLE_COLORS.map((c) => (
                  <button
                    key={c} onClick={() => setColor(c)}
                    className={`h-7 w-7 rounded-full border-2 transition ${color === c ? "border-noir scale-110" : "border-transparent"}`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Formă</label>
            <div className="mt-2 grid grid-cols-5 gap-2">
              {SHAPES.map((s) => (
                <button key={s.id} onClick={() => setShape(s.id)}
                  className={`flex flex-col items-center gap-2 rounded-xl border-2 p-3 transition ${
                    shape === s.id ? "border-champagne bg-champagne/10" : "border-border hover:border-muted-foreground/40"
                  }`}>
                  <ShapeIcon shape={s.id} />
                  <span className="text-[10px] text-muted-foreground">{s.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Note (opțional)</label>
            <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)}
              placeholder="Note despre această masă..."
              className="mt-2 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none focus:border-champagne resize-none" />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <button onClick={() => setOpen(false)} className="rounded-full bg-secondary px-5 py-2.5 text-sm">
            Anulează
          </button>
          <button onClick={submit} className="rounded-[4px] bg-noir text-ivory px-6 py-2.5 text-sm hover:opacity-90">
            Salvează
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ShapeIcon({ shape }: { shape: Shape }) {
  const cls = "border-2 border-noir/50";
  switch (shape) {
    case "round": return <div className={`${cls} h-6 w-6 rounded-full`} />;
    case "rect": return <div className={`${cls} h-4 w-8 rounded`} />;
    case "square": return <div className={`${cls} h-6 w-6 rounded`} />;
    case "oval": return <div className={`${cls} h-4 w-8 rounded-full`} />;
    case "presidium": return <div className={`${cls} h-3 w-9 rounded-sm`} />;
  }
}
