"use client";

import Link from "next/link";
import { useEffect } from "react";

export default function ErrorPage({ error, reset }: { error: Error; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-6">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-3xl text-foreground">Ceva nu a mers bine</h1>
        <p className="mt-3 text-sm text-muted-foreground">Reîncarcă pagina sau întoarce-te acasă.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button onClick={reset} className="rounded-[4px] bg-primary px-6 py-3 text-sm text-primary-foreground hover:opacity-90">
            Reîncearcă
          </button>
          <Link href="/" className="rounded-full border border-border bg-card px-6 py-3 text-sm hover:bg-secondary">
            Acasă
          </Link>
        </div>
      </div>
    </div>
  );
}
